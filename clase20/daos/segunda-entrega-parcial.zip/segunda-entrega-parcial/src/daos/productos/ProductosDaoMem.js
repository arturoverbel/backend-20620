import ContenedorMemoria from "../../contenedores/ContenedorMemoria.js"

class ProductosDaoMem extends ContenedorMemoria {

}

export default ProductosDaoMem
